# Credits

Extension Creator:  

Discord: cj#1211  
Github: https://www.github.com/ou1z  
V3rmillion: ou1z  

Dependencies:  

Herrtt, and Stravant for "luamin.js"
